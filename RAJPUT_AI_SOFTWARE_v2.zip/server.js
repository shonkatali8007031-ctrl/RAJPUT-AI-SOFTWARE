// Secure backend proxy for OTCharts-style candle API.
// Keep OTCHARTS_API_KEY on the server. Never put it in public/index.html.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const BASE = process.env.OTCHARTS_BASE_URL || 'https://otcharts.com';
const KEY = process.env.OTCHARTS_API_KEY;
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css'};
http.createServer(async (req,res)=>{
  const u = new URL(req.url,'http://localhost');
  if(u.pathname==='/api/candles'){
    if(!KEY){res.writeHead(503,{'Content-Type':'text/plain'});return res.end('Server API key is not configured.');}
    const symbol=u.searchParams.get('symbol')||'EURUSD_otc';
    const venue='quotex'; // OTCharts book id for Quotex OTC/live feed
    const tf=u.searchParams.get('tf')||'60';
    const limit=Math.min(200,Math.max(20,Number(u.searchParams.get('limit')||80)));
    try{
      const endpoint=`${BASE}/v1/candles?venue=${encodeURIComponent(venue)}&symbol=${encodeURIComponent(symbol)}&tf=${encodeURIComponent(tf)}&limit=${limit}`;
      const upstream=await fetch(endpoint,{headers:{'Authorization':`Bearer ${KEY}`,'Accept':'application/json'}});
      const body=await upstream.text();
      res.writeHead(upstream.status,{'Content-Type':'application/json','Cache-Control':'no-store'});
      return res.end(body);
    }catch(e){res.writeHead(502,{'Content-Type':'text/plain'});return res.end('Market data provider request failed: '+e.message);}
  }
  let file=u.pathname==='/'?'/index.html':u.pathname;
  const full=path.join(__dirname,'public',path.normalize(file).replace(/^(\.\.[/\\])+/, ''));
  fs.readFile(full,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found');}
    res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream'});res.end(data);});
}).listen(PORT,()=>console.log(`Rajput AI running on port ${PORT}`));
